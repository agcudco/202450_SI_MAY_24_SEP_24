import './App.css';
import { AuthorTable } from './components/Author';

function App() {
  return (
    <div className="App">
      <h1>Authores</h1>
      <AuthorTable></AuthorTable>
    </div>
  );
}

export default App;
