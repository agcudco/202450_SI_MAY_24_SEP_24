import { useEffect, useState } from "react";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';

interface Author {
    id: number;
    name: string;
    lastName: string;
    dni: string;
    dateBirth: Date;
    country: string;
}

export const AuthorTable: React.FC = () => {

    const [authors, setAuthors] = useState<Author[]>([]);
    const [loading, setLoading] = useState<boolean>(true);


    useEffect(() => {
        //fetch - async - await
        const fetchAuthors = async () => {
            try {
                const response = await fetch('http://localhost:8080/author/');
                if (!response.ok) {
                    throw new Error('Error fetching authors');
                }
                const data: Author[] = await response.json();
                setAuthors(data);
            } catch (error) {
                console.log('Error fetching authros', error);
            } finally {
                setLoading(false);
            }
        }
        fetchAuthors();
    }, []);

    return (
        <div>
            <DataTable value={authors} loading={loading} tableStyle={{ minWidth: '50rem' }}>
                <Column field="id" header="Id"></Column>
                <Column field="name" header="Nombre"></Column>
                <Column field="lastName" header="Apellido"></Column>
                <Column field="dni" header="Cédula Ciudadanía"></Column>
                <Column field="dateBirth" header="Fecha Nacimiento"></Column>
                <Column field="country" header="País"></Column>
            </DataTable>
        </div>
    );
}